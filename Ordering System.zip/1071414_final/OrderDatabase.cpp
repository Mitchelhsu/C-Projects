// OrderDatabase.cpp
// Member-function definitions for class OrderDatabase.
#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
#include "OrderDatabase.h" // OrderDatabase class definition

// OrderDatabase default constructor initializes orders
OrderDatabase::OrderDatabase()
{
   loadOrderDetails();
} // end OrderDatabase default constructor

// OrderDatabase destructor
OrderDatabase::~OrderDatabase()
{
   saveOrderDetails();
} // end OrderDatabase destructor

void OrderDatabase::loadOrderDetails()
{
	ifstream inFile("Orders.dat", ios::binary);

	if (!inFile)
		cerr << "File could not be opened. " << endl;
	else
	{
		Order tempt;
		while (inFile.read(reinterpret_cast<char*>(&tempt), sizeof(tempt)))
		{
			orders.push_back(tempt);
		}
	}
}

string OrderDatabase::generateOrderNumber() const
{
   srand( static_cast< unsigned int >( time( nullptr ) ) );

   string orderNumber;
   do
   {
      orderNumber.push_back( rand() % 26 + 'A' );
      for( int i = 1; i <= 9; i++ )
         orderNumber.push_back( rand() % 10 + '0' );
   } while( existOrder( orderNumber ) );

   return orderNumber;
}

void OrderDatabase::pushBack( Order &newOrder )
{
   orders.push_back( newOrder );
}

bool OrderDatabase::existOrders( string email ) const
{
   for( size_t i = 0; i < orders.size(); i++ )
      if( orders[ i ].getEmail() == email )
         return true;
   return false;
}

void OrderDatabase::displayOrders( string email, string name ) const
{
	vector< Order > theorders;
	int count = 1;
	cout << "Your order history:" << endl << endl;
	for (int i = 0; i < orders.size(); i++)
	{
		if (email == orders[i].getEmail())
		{
			cout << "Code    Order no.    Name" << endl;
			theorders.push_back(orders[i]);
			cout << "   " << count << "   " << orders[i].getOrderNumber() << "     " << name << endl;
			count++;
		}
	}

	int choice = 0;
	while (choice<1 || choice>count - 1)
	{
		cout << "Choose a code ( 1 ~ " << count - 1 << " ) : ";
		cin >> choice;
	}

	cout << "Your order history: " << endl;
	cout << "Item Code" << setw(44) << "Item";
	cout << "  Price   Quantity Subtotal" << endl;
	for (int i = 0; i < theorders.size(); i++)
	{
		if (i == choice - 1)
			theorders[i].displayOrderDetails();
	}
}

void OrderDatabase::saveOrderDetails()
{
	ofstream save("Orders.dat", ios::binary);

	if (!save)
		cerr << "File could not be saved. " << endl;
	else
	{
		for (int i = 0; i < orders.size(); i++)
		{
			save.write(reinterpret_cast<char*>(&orders[i]), sizeof(orders[i]));
		}
	}
}

bool OrderDatabase::existOrder( string orderNumber ) const
{
   for( size_t i = 0; i < orders.size(); i++ )
      if( orders[ i ].getOrderNumber() == orderNumber )
         return true;
   return false;
}