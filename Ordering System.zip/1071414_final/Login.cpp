#include <iostream>
#include "Login.h" // Registration class definition
#include "OrderDatabase.h" // OrderDatabase class definition
#include "MakingOrder.h" // MakingOrder class definition
#include "OrderHistory.h" // Member class definition

Login::Login( AccountDatabase &theAccountDatabase )
   : accountDatabase( theAccountDatabase )
{
}

void Login::run()
{
	string email;
	cout << "Email (Account number) (0 to end): ";
	cin >> email;
	if (email == "0")
		return;

	while (!accountDatabase.existAccount(email))
	{
		cout << "No account exists with the e-mail!" << endl;
		cout << "Email (Account number) (0 to end): ";
		cin >> email;
		if (email == "0")
			return;
	}

	string pass;
	cout << "Password: ";
	cin >> pass;
	while (!accountDatabase.authenticateUser(email, pass))
	{
		cout << "Invalid password. Please try again." << endl;
		cout << "Email (Account number) (0 to end): ";
		cin >> email;
		if (email == "0")
			return;

		cout << "Password: ";
		cin >> pass;
	}
	OrderDatabase orders;
	OrderHistory history(email, accountDatabase, orders);
	MakingOrder order(email, accountDatabase, orders);
	while (accountDatabase.authenticateUser(email, pass))
	{
		int choice = enterChoice();
		switch (choice)
		{
		case 1:
			order.run();
			break;
		case 2:
			history.run();
			break;
		case 3:
			//orders.~OrderDatabase();
			return;
		}
	}
}

int Login::enterChoice()
{
   cout << "\nEnter your choice\n"
      << "1. Making order\n"
      << "2. Order history\n"
      << "3. Back to top\n? ";

   int menuChoice;
   cin >> menuChoice;
   return menuChoice;
}