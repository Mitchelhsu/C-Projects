#include <iostream>
#include <iomanip>
#include "MakingOrder.h" // MakingOrder class definition

MakingOrder::MakingOrder( string theEmail, AccountDatabase &theAccountDatabase, OrderDatabase &theOrderDatabase )
   : email( theEmail ),
     accountDatabase( theAccountDatabase ),
     orderDatabase( theOrderDatabase )
{
}

void MakingOrder::run()
{
	currentAccount.setEmail(email);
	int *cart = accountDatabase.getCart(email);
	currentAccount.setCart(cart);
	currentAccount.displayCart();

	int food;
	cout << "Enter food code: ";
	cin >> food;

	int quantity;
	cout << "Enter quantity: ";
	cin >> quantity;

	currentAccount.modifyCart(food, quantity);
	currentAccount.displayCart();

	while (true)
	{
		int choice = enterChoice();
		switch (choice)
		{
		case 1:
			currentAccount.displayCart();
			cout << "Enter food code: ";
			cin >> food;
			cout << "Enter quantity: ";
			cin >> quantity;
			currentAccount.modifyCart(food, quantity);
			currentAccount.displayCart();
			break;
		case 2:
			checkout();
			return;
		case 3:
			return;
		}
	}
}

int MakingOrder::enterChoice()
{
   cout << "\n1. Continue Shopping\n"
        << "2. Proceed to Checkout\n"
        << "3. Abandon\n? ";

   int menuChoice;
   cin >> menuChoice;
   return menuChoice;
}

void MakingOrder::checkout()
{
	string ordernum = orderDatabase.generateOrderNumber();
	string name = accountDatabase.getName(email);
	string adress = accountDatabase.getAddress(email);
	string phone = accountDatabase.getPhone(email);

	cout << "Order Number: " << ordernum << endl;
	cout << "Full name: " << name << endl;
	cout << "Shipping Address: " << adress << endl;
	cout << "Phone Number: " << phone << endl;
	cout << "Bank account: �X�@���w 0062013162077139" << endl;
	cout << endl;
	cout << "Item Code" << setw(44) << "Item";
	cout << "  Price   Quantity Subtotal" << endl;

	currentAccount.displayOrders();
	
	Order theorder(ordernum, email);
	theorder.setOrderDetails(currentAccount.getCart());
	orderDatabase.pushBack(theorder);
}