#include <iostream>
#include "Registration.h" // Registration class definition

Registration::Registration( AccountDatabase &theAccountDatabase )
   : accountDatabase( theAccountDatabase )
{
}

void Registration::run()
{
	string email;
	cout << "Enter your e-mail address (account number) (0 to end):";
	cin >> email;
	if (email == "0")
		return;

	while (accountDatabase.existAccount(email))
	{
		cout << "An account already exists with the e-mail!" << endl;
		cout << "Enter your e-mail address (account number) (0 to end):";
		cin >> email;
		if (email == "0")
			return;
	}

	Account newAcc;
	newAcc.setEmail(email);

	string pass;
	cout << "Enter your password: ";
	cin >> pass;
	newAcc.setPassword(pass);

	string name;
	cout << "Enter your name: ";
	cin >> name;
	newAcc.setName(name);

	string adress;
	cout << "Enter your physical address: ";
	cin >> adress;
	newAcc.setAddress(adress);

	string number;
	cout << "Enter your phone number: ";
	cin >> number;
	newAcc.setPhone(number);


	accountDatabase.pushBack(newAcc);
    cout << "\nRegistration Successfully!\n";
}